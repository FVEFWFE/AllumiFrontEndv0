"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AccordionFaq } from "../_sections/accordion-faq"

const heroData = {
  tagline: "Affiliate Program",
  title: "Earn 40% Recurring Commissions",
  subtitle:
    "Partner with Allumi and help Skool community owners transform their engagement while earning generous monthly recurring revenue.",
  actions: [
    {
      _id: "primary-cta",
      href: "#apply",
      label: "Become an Affiliate",
      type: "primary" as const,
    },
    {
      _id: "secondary-cta",
      href: "#learn-more",
      label: "Learn More",
      type: "secondary" as const,
    },
  ],
}

const statsData = [
  {
    value: "40%",
    label: "Recurring Commission",
    sublabel: "Forever",
  },
  {
    value: "No Time Limits",
    label: "Commission Duration",
    sublabel: "",
  },
  {
    value: "180 Days",
    label: "Cookie Duration",
    sublabel: "",
  },
]

const earningsExamples = [
  {
    referrals: 5,
    price: 99,
    commission: 40,
    monthly: 148.5,
  },
  {
    referrals: 10,
    price: 99,
    commission: 40,
    monthly: 297,
  },
  {
    referrals: 25,
    price: 99,
    commission: 40,
    monthly: 742.5,
  },
]

const benefitsData = [
  {
    title: "High Conversion Rate",
    description: "Our product solves real problems for Skool communities, making it easy to convert referrals.",
  },
  {
    title: "Marketing Resources",
    description: "Access banners, email templates, and content to help you promote effectively.",
  },
  {
    title: "Dedicated Support",
    description: "Get help from our affiliate team to maximize your earnings potential.",
  },
  {
    title: "No Minimum Payout",
    description: "Get paid monthly regardless of the amount you've earned.",
  },
  {
    title: "Product You Can Trust",
    description: "Promote a tool that genuinely helps communities thrive and grow.",
  },
  {
    title: "Bonus Opportunities",
    description: "Earn extra bonuses during special promotions and campaigns.",
  },
]

const stepsData = [
  {
    step: "1",
    title: "Sign Up",
    description:
      "Apply to join our affiliate program. We'll review your application and get you set up with your unique referral link.",
  },
  {
    step: "2",
    title: "Share",
    description:
      "Promote Allumi to your audience using your referral link. Share on social media, your website, or directly with Skool community owners.",
  },
  {
    step: "3",
    title: "Earn",
    description:
      "Get 40% recurring commission for every customer you refer. Track your earnings in real-time and get paid monthly.",
  },
]

const faqData = {
  layout: "accordion" as const,
  heading: {
    title: "Frequently Asked Questions",
    subtitle: "Everything you need to know about our affiliate program",
    align: "center" as const,
  },
  questions: {
    items: [
      {
        _id: "faq-1",
        _title: "Who can become an Allumi affiliate?",
        answer:
          "Anyone with an audience of Skool community owners, content creators, or entrepreneurs can apply. We look for partners who align with our values and can genuinely help community builders succeed.",
      },
      {
        _id: "faq-2",
        _title: "How and when do I get paid?",
        answer:
          "Commissions are paid monthly via Stripe on the 15th of each month for the previous month's earnings. There's no minimum payout threshold - you get paid regardless of the amount earned.",
      },
      {
        _id: "faq-3",
        _title: "How long do I earn commissions for?",
        answer:
          "You earn 40% recurring commissions for the entire lifetime of every customer you refer. As long as they remain a paying customer, you continue earning monthly commissions.",
      },
      {
        _id: "faq-4",
        _title: "What marketing materials are provided?",
        answer:
          "We provide banners, email templates, social media content, case studies, and detailed product information. You'll also get access to our affiliate resource center with best practices and promotional strategies.",
      },
      {
        _id: "faq-5",
        _title: "Can I refer myself or my own community?",
        answer:
          "No, self-referrals are not permitted. However, if you genuinely use Allumi for your own community and want to promote it to others, that's perfectly fine and encouraged.",
      },
      {
        _id: "faq-6",
        _title: "Is there a dashboard to track my referrals?",
        answer:
          "Yes! You'll have access to a comprehensive affiliate dashboard where you can track clicks, conversions, earnings, and payment history in real-time.",
      },
    ],
  },
}

export default function AffiliatePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-24 bg-gradient-to-b from-background to-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="secondary" className="mb-6">
              {heroData.tagline}
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">{heroData.title}</h1>
            <p className="text-xl text-muted-foreground mb-8 text-balance">{heroData.subtitle}</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {heroData.actions.map((action) => (
                <Button key={action._id} variant={action.type === "primary" ? "default" : "outline"} size="lg" asChild>
                  <a href={action.href}>{action.label}</a>
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {statsData.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-primary mb-2">{stat.value}</div>
                <div className="text-lg font-semibold mb-1">{stat.label}</div>
                {stat.sublabel && <div className="text-sm text-muted-foreground">{stat.sublabel}</div>}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Commission Structure */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Simple Commission Structure</h2>
              <p className="text-lg text-muted-foreground">Earn recurring commissions for every customer you refer</p>
            </div>

            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-2xl font-bold mb-6">Your Earnings</h3>
                <ul className="space-y-4">
                  <li className="flex items-center gap-3">
                    <span className="text-primary">✓</span>
                    <span>40% of every monthly payment</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="text-primary">✓</span>
                    <span>Commissions for the customer lifetime</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="text-primary">✓</span>
                    <span>Monthly payouts via Stripe</span>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="text-2xl font-bold mb-6">Example Earnings:</h3>
                <div className="space-y-4">
                  {earningsExamples.map((example, index) => (
                    <div key={index} className="bg-background p-4 rounded-lg border">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">
                          {example.referrals} referrals × ${example.price}/mo × {example.commission}%
                        </span>
                        <span className="text-lg font-bold text-primary">${example.monthly}/mo</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Partner Section */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Why Partner with Allumi?</h2>
              <p className="text-lg text-muted-foreground">Join a program designed for your success</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {benefitsData.map((benefit, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="text-xl">{benefit.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">{benefit.description}</CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">How It Works</h2>
              <p className="text-lg text-muted-foreground">Start earning in three simple steps</p>
            </div>

            <div className="space-y-12">
              {stepsData.map((step, index) => (
                <div key={index} className="flex gap-6 items-start">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xl font-bold">
                    {step.step}
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold mb-3">{step.title}</h3>
                    <p className="text-lg text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <AccordionFaq {...faqData} eventsKey="affiliate-events" />

      {/* CTA Section */}
      <section id="apply" className="py-24 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Ready to Start Earning?</h2>
            <p className="text-xl mb-8 opacity-90">
              Join our affiliate program today and start earning 40% recurring commissions on every referral.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" asChild>
                <a href="/affiliate-apply">Apply Now</a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary bg-transparent"
                asChild
              >
                <a href="mailto:affiliates@allumi.io">Contact Support</a>
              </Button>
            </div>
            <p className="text-sm mt-6 opacity-75">Questions? Email us at affiliates@allumi.io</p>
          </div>
        </div>
      </section>
    </div>
  )
}
