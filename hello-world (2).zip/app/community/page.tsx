import { CommunityFeed } from "@/components/community/community-feed"

export default function CommunityPage() {
  return <CommunityFeed />
}
